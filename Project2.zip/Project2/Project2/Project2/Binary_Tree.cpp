
#include <cstddef>
#include <sstream>
#include <stdexcept>
#include <string>
#include <algorithm>
#include "BTNode.h"
#include <vector>
#include "Binary_Tree.h"
using namespace std;

Binary_Tree<std::string> the_tree;
void Binary_Tree<char>::insert(char data)
{
	the_tree.setRoot()
}