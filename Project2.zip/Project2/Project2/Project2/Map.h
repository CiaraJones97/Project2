#pragma once
#include <map>

struct node
{
	node* left;
	node* right;

	char key;
	char value;

};
