#pragma once
#ifndef BTNODE_H_
#define BTNODE_H_
#include <sstream>
#include <map>
#include <set>

/** A node for a Binary Tree. */
template<typename Char>
struct BTNode
{
	// Data Fields
	Char data;
	BTNode* left;
	BTNode* right;

	// Constructor
	BTNode(const Char& the_data,
		BTNode<Char>* left_val = NULL,
		BTNode<Char>* right_val = NULL) :
		data(the_data), left(left_val), right(right_val) {}

	// Destructor (to avoid warning message)
	virtual ~BTNode() {}

	// to_string
	virtual std::string to_string() const {
		std::ostringstream os;
		os << data;
		return os.str();
	}
}; // End BTNode

   // Overloading the ostream insertion operator
template<typename Char>
std::ostream& operator<<(std::ostream& out,
	const char& node) {
	return out << node.to_string();
}

#endif
