#include "Binary_Tree.h"

template<typename Item_Type>
void Binary_Tree<Item_Type>::insert(map<char,string> item)
{
	parent_root->data = ' ';

	for (map<char, string>::iterator it = item.begin(); it != item.end(); it++)
	{
		int i = 0;
		root = parent_root->left;
		while (i < second.size())
		{
			if (*it.second[i] == ".")
			{
				root = root->left;
			}
			else
			{
				if (*it.second[i] == "-")
				{
					root = root->right;
				}

			}
			i++;
			
		}
		
		root->data = *it.first;
		cout << root->data;
	}
}